# Krátkovlnná absorpce CO₂: omezený numerický experiment a částečný audit

Zpracováno 19. 11. 2026. Zpráva `index.html` začíná podrobným výkladem pro laika,
potom uvádí metody, skutečně vypočtené výsledky a otevřené části původního zadání.
Je čitelná bez internetu. Primární samostatné HTML leží také vedle tohoto adresáře.

## Co tento balíček skutečně počítá

Vlastní čárovou absorpci slunečního záření CO₂ a H₂O v předepsaném sloupci,
včetně vodního kontinua, zjednodušeného Rayleighova rozptylu a odrazu na povrchu.
Základní teplota, vlhkost a ostatní vlastnosti profilu zůstávají při změně CO₂ pevné.
Kromě přímé absorpce CO₂ se samostatně vyčísluje změna absorpce H₂O i celé atmosféry.
Sluneční záření je definováno původem, zahrnuje proto i sluneční infračervený ocas.

Není zde vlastní úplná dlouhovlnná stratosférická adaptace ani simulace mezní vrstvy.
Žádná vlastní hodnota není globální roční klimatologický průměr. SOCRATES,
CESM2, RRTMG a RRTMGP nebyly spuštěny. Jejich instalace a přesná reprodukce je
neprovedenou částí, nikoli prokázanou nemožností těchto nástrojů.

## Spuštění

Použito: Python 3.9.6 na macOS / Apple Silicon; přesné knihovny v `requirements.txt`
a `environment.json`. Novější kompatibilní Python může mít pro tyto starší přesné
verze knihoven odlišnou dostupnost binárních balíčků; nejvěrnější je Python 3.9.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
export MPLCONFIGDIR="$PWD/.mpl-cache"
export NUMBA_CACHE_DIR="$PWD/.numba-cache"
export CO2_CACHE="$PWD/.optics-cache"
python model.py --tests
python model.py --profile tropical --factor 5 --cutoff 1e-26 --wing 25 --dz 4
python model.py --profile tropical --factor 5 --cutoff 1e-26 --wing 10 --dz 4
python model.py --profile tropical --factor 2.5 --cutoff 1e-26 --wing 10 --dz 4 --base-only
python model.py --profile tropical --factor 5 --cutoff 1e-27 --wing 10 --dz 4 --base-only
python run_suite.py
python audit.py
python check_cohen.py
python verify.py
python build_report.py
```

Výpočet může podle hardwaru a vyrovnávací paměti trvat několik minut až déle.
Numba při prvním běhu kompiluje funkce. Pracovní optické cache mohou zabrat stovky MB
a nejsou přiloženy; vstupy a výsledky přiloženy jsou. Na hlavní výstup nemá být
použito zaokrouhlení během výpočtu. Pro kontrolu více souběžných běhů stačí používat
oddělené cache nebo je spouštět postupně, jak je uvedeno zde.

`experiments.json` je seznam skutečně dokončených konfigurací. `suite_coarse.json`
popisuje hrubší šestiprofilovou sadu. Hlavní konfigurace má parametr `factor = 5`;
název není označením přesnosti. Krok je faktorem násobená základní mřížka uvedená
ve `grid_segments()`.

## Rovnice, jednotky a čáry

- Čistý tok dolů je kladný: F_net = F_down − F_up.
- Absorpce vrstvy = F_net na horní hranici − F_net na dolní hranici.
- Změna veličiny = stav při konečné koncentraci − stav při počáteční koncentraci.
- Povrchová SW absorpce = (1 − albedo) × (přímý + difuzní sestupný SW tok).
- Optická tloušťka = průřez v cm²/molekulu × sloupec molekul v cm⁻².
- Hydrostatický sloupec je Δp / (g M_air) × N_A / 10⁴.
- Změna radiačního ohřevu je g ΔA / (c_p Δp); pro K/den násobíme 86 400.

Intenzity HITRAN již obsahují přirozené izotopové zastoupení. Používají se všechny
isotopology přítomné v exportu, bez dalšího násobení jejich podíly. Teplotní přepočet
používá partiční sumy HAPI TIPS2025, Boltzmannův faktor a faktor stimulované emise. Šířka je
směsí air/self broadening. Posun čáry je škálován parciálním tlakem cizího plynu.
H₂O má odečtený podstavec Voigtova profilu ve vzdálenosti 25 cm⁻¹ v souladu s
konvencí kontinua. Testy s ořezem 5 nebo 10 cm⁻¹ záměrně vynechávají část blízkých
křídel; hlavní běh používá 25 cm⁻¹. Není zapnuto line mixing, CO₂ CIA ani speciální
sublorentzovská oprava CO₂.

V kódu zůstává malá konverze dřívější pracovní optické cache s odlišným podstavcem.
Tato časná cache není distribuována. Čerstvý běh přímo používá správný podstavec
25 cm⁻¹; rozdíl případných posledních číslic při konverzi je dán float32 ukládáním.

## Přenos a stav atmosféry

Dvouproudové rovnice pro rozptýlené toky používají μ = 1/√3 a izotropní rozptyl.
Přímý sluneční tok je samostatný; vrstvy jsou skládány s opakovanými odrazy.
Konzervativní limit má analytické řešení. Rayleighova optická tloušťka používá
λ⁻⁴ zákon s obvyklou viditelnou/NIR korekcí; mimo hlavní obor jde o extrapolaci.
Přenos nezahrnuje absorpci ostatních atmosférických plynů, oblaky ani aerosoly.
Povrchové albedo je spektrálně konstantní a Lambertovo.

Základní sluneční zenitový úhel 60° po polovinu času dává pro vstup celkový faktor
1/4. Nepopisuje přesnou prostorovou a časovou distribuci slunečních úhlů. Nemůže
nahradit globální integraci nelineárního přenosu.

Tropopauza je provozní hranice: minimum teploty na zvolené výškové mřížce do 25 km.
Tento jednoduchý ukazatel není úplnou WMO definicí tropopauzy. V tropickém hlavním
profilu je hranicí 16 km. Vertikální rozdělení hrubé sady je málo přesné.
Hodnota `above_tropopause_to80` označuje vše nad touto hranicí až do 80 km, včetně
mezosférické části nad stratopauzou; není to čistě stratosférický integrál.

Změny obsahu H₂O v citlivostních testech škálují referenční optické tloušťky.
Samorozšíření a nelineární self kontinuum se znovu neřeší. Nejde proto o plně
fyzikální nové vlhkostní profily. CO₂ self broadening je předpočítán při 280 ppm.
Pevná střední molární hmotnost vzduchu aproximuje i vlhké vrstvy.

Absorpce slunečního záření se počítá i v horních vrstvách, ale jejich non-LTE
teplotní a emisní odezva není řešena. Graf K/den se nesmí integrovat v čase jako
klimatická předpověď bez další fyziky a zpětných vazeb.

## Vstupní snímky a jejich získání

Původní soubory jsou v `data/`; `manifest_sha256.json` fixuje použité bajty.

- `CO2_HITRAN.par` a `H2O_HITRAN.par`: uživateli dostupný export HITRANonline
  z 18. 11. 2026, formát 160 znaků na záznam, rozsah 0–26 000 cm⁻¹.
  Neoznačujeme tento neversionovaný živý export za jednoznačně zmrazené HITRAN2024.
  Počty, izotopology a otisky jsou v `*_metadata.json`. Úplné původní exporty jsou
  přiloženy pro soukromou reprodukci uživatele; nejde o zveřejnění nové databáze.
- `solar_1nm.nc`: LASP TSIS-1 HSRS v2, datum vytvoření 30. 11. 2022, 202–2730 nm,
  rozlišení 1 nm a vzorkování 0,1 nm. Po převodu na vlnočet se používá příslušný
  Jacobián, 10⁷ / ν², pro vstup v W/m²/nm.
- `solar_full.csv`: LASP binned HSRS full-spectrum extension, staženo 19. 11. 2026.
  Mimo oblast hlavního HSRS doplňuje spektrum, především >2730 nm.
- `absco-ref_wv-mt-ckd.nc`: AER MT_CKD 4.3; původní copyright a podmínky jsou
  zachovány v netCDF metadatech. Použita lineární interpolace, ne původní kubická.
- `afgl_1a.csv` až `afgl_1f.csv`: tabulky AFGL 1986 z repozitáře
  https://github.com/rayference/afgl1986 . Tlak je hPa, teplota K, H₂O ppm.
- `data/cohen/*.nc`: tři vybrané autorské výstupy z archivu
  https://doi.org/10.5281/zenodo.16929030 . NetCDF metadata uvádějí
  `konrad 1.0.2-dev0`; kontrolujeme uložené adaptované stavy, ne okamžité experimenty.

Veřejné zdroje umí stáhnout `acquire_data.py`. Při existenci souboru jej nepřepisuje.
Později aktualizovaný živý zdroj se může lišit od přiloženého snímku. HITRAN vyžaduje
vlastní legitimní export; případný nový export importuje `--hitran-dir ADRESAR`.
Skript nezískává ani neukládá přihlašovací údaje. Přiložený snímek je preferován.

## Výsledky a jejich interpretace

- `results/fluxes.csv`: všechny dokončené změny toků v W/m².
- `results/height_profiles.csv`: změna absorpce po vrstvách (W/m² na vrstvu),
  tlak ve středu (hPa) a změna rychlosti ohřevu (K/den).
- `results/spectra.csv`: spektrální integrály v buňkách 10 cm⁻¹. Jejich hodnoty
  jsou W/m² na buňku, nikoli spektrální hustoty. Pro graf podle vlnové délky se
  dělí šířkou buňky v µm.
- JSON běhy obsahují i absolutní čisté, přímé, difuzní a vzestupné SW toky po
  rozhraních tam, kde je výstup `states` přítomen.
- `publication_audit.json`: vlastní aritmetika převzatých údajů Shine a
  explicitně označené publikované hodnoty Allen. Nejde o nezávislé klima simulace.
- `cohen_data_check.json`: maximální absolutní rozdíly uložených autorských polí.
- `tests.json`, `verification.json`: skutečné výsledky kontrol řešiče a tabulek.

Počet zobrazených desetinných míst neznačí známou fyzikální nejistotu. Numerické
citlivosti nejsou intervalem spolehlivosti a jejich kvadratický součet není
ospravedlněný rozklad celkové nejistoty. Statistické intervaly Allen jsou 90%,
ne standardní odchylky ani 95% intervaly.

## Hlavní vědecké zdroje

1. Shine, Byrom & Checa-Garcia (2022), https://doi.org/10.1002/asl.1116
2. Allen et al. (2024), https://doi.org/10.5194/acp-24-11207-2024
3. Hogan & Matricardi (2020), https://doi.org/10.5194/gmd-13-6501-2020
4. Cohen, Pincus & Polvani (2026), https://doi.org/10.1038/s41561-026-01965-8
5. Etminan et al. (2016), https://doi.org/10.1002/2016GL071930
6. Myhre et al. (1998), https://doi.org/10.1029/98GL01908
7. HITRAN, https://www.hitran.org/docs/definitions-and-units/
8. Coddington et al. (2023), HSRS v2, https://doi.org/10.1029/2022EA002637
9. HAPI: Kochanov et al. (2016), https://doi.org/10.1016/j.jqsrt.2016.03.005
10. MT_CKD: Mlawer et al. (2012), https://doi.org/10.1098/rsta.2011.0295

Kritický závěr se vztahuje ke konkrétním provedeným kontrolám. Žádná zdejší
omezená shoda není úplným potvrzením publikace a odlišnost nesrovnatelných
experimentů není důkazem její chyby.
