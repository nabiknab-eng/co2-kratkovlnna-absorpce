"""Independent limited LBL shortwave experiment; not a climate model.

Solar origin defines SW, including solar radiation at wavelengths >4 um.
Voigt lines, HITRAN natural abundances, MT_CKD 4.3, isotropic two-stream
Rayleigh scattering, Lambertian surface. All fluxes positive downward net.
Read README.md for omissions and the exact interpretation of the results.
"""
from pathlib import Path
import contextlib, io, json, hashlib, os, argparse, time
import numpy as np
from scipy.special import wofz
from numba import njit
from netCDF4 import Dataset

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; RESULT=ROOT/'results'
CACHE=Path(os.environ.get('CO2_CACHE', str(ROOT/'.cache')))
G=9.80665; CP=1004.; NA=6.02214076e23; M_AIR=.0289647
KB=1.380649e-23; C=299792458.; C2=1.438776877

with contextlib.redirect_stdout(io.StringIO()):
    import hapi

def coefficients(n=24):
    # Weideman rational approximation to the Faddeeva function (1994).
    m=2*n; L=np.sqrt(n/np.sqrt(2.)); k=np.arange(-m+1,m)
    t=L*np.tan(k*np.pi/m/2)
    f=np.r_[0., np.exp(-t*t)*(L*L+t*t)]
    a=np.real(np.fft.fft(np.fft.fftshift(f)))/(2*m)
    return L,a[1:n+1][::-1].copy()

WL,WA=coefficients()

@njit(cache=True)
def voigt(dx,sigma,gamma):
    z=(dx+1j*gamma)/(sigma*np.sqrt(2.))
    if abs(z)>12.:
        iz=1/z; term=1.+0j; poly=1.+0j
        for j in range(1,9):
            term*=iz*iz*(2*j-1)/2; poly+=term
        w=1j*iz*poly/np.sqrt(np.pi)
    else:
        d=WL-1j*z; q=(WL+1j*z)/d; poly=0.+0j
        for a in WA:poly=poly*q+a
        w=2*poly/(d*d)+1/np.sqrt(np.pi)/d
    return max(0.,w.real/(sigma*np.sqrt(2*np.pi)))

@njit(cache=True)
def line_sum(nu0,step,count,centers,strengths,sigma,gamma,wing,pedestal):
    out=np.zeros(count)
    for j in range(len(centers)):
        lo=max(0,int(np.ceil((centers[j]-wing-nu0)/step)))
        hi=min(count,int(np.floor((centers[j]+wing-nu0)/step))+1)
        if lo>=hi:continue
        # MT_CKD's water line/continuum partition uses a 25 cm^-1 pedestal.
        base=voigt(25.,sigma[j],gamma[j]) if pedestal else 0.
        for k in range(lo,hi):
            out[k]+=strengths[j]*max(0.,voigt(nu0+k*step-centers[j],sigma[j],gamma[j])-base)
    return out

@njit(cache=True)
def old_pedestal_correction(nu0,step,count,centers,S,sigma,gamma,wing):
    """Upgrade the early temporary cache; never changes raw line input data."""
    diff=np.zeros(count+1)
    for j in range(len(centers)):
        lo=max(0,int(np.ceil((centers[j]-wing-nu0)/step)))
        hi=min(count,int(np.floor((centers[j]+wing-nu0)/step))+1)
        if lo>=hi:continue
        v=S[j]*(voigt(wing,sigma[j],gamma[j])-voigt(25.,sigma[j],gamma[j]))
        diff[lo]+=v;diff[hi]-=v
    return np.cumsum(diff[:-1])

def parse_lines(name):
    target=DATA/f'{name}_lines.npz'
    if target.exists():
        with np.load(target) as f:return {k:f[k] for k in f.files}
    raw=(DATA/f'{name}_HITRAN.par').read_bytes(); lines=raw.splitlines()
    assert all(len(l)==160 for l in lines)
    a=np.frombuffer(b''.join(lines),dtype='S1').reshape(-1,160)
    def col(i,j,kind=float):return np.ascontiguousarray(a[:,i:j]).view(f'S{j-i}').ravel().astype(kind)
    iso=np.array([10 if i=='0' else 11 if i=='A' else 12 if i=='B' else int(i) for i in col(2,3,str)])
    d=dict(nu=col(3,15),S=col(15,25),ga=col(35,40),gs=col(40,45),E=col(45,55),n=col(55,59),shift=col(59,67),iso=iso)
    mol={'H2O':1,'CO2':2}[name]
    d['mass']=np.array([hapi.ISO[(mol,int(i))][3] for i in iso])
    np.savez_compressed(target,**d)
    meta=dict(records=len(lines),nu_min=float(d['nu'].min()),nu_max=float(d['nu'].max()),
              sha256=hashlib.sha256(raw).hexdigest(),isotopes=sorted(map(int,set(iso))),
              edition='Unversioned HITRANonline export, snapshot 2026-11-18; not certified as frozen HITRAN2024')
    (DATA/f'{name}_metadata.json').write_text(json.dumps(meta,indent=2))
    return d

def grid_segments(factor=1.):
    # Inspired by the explicitly documented CKDMIP shortwave grid. Midpoint cells.
    return [(250,2200,.002*factor),(2200,2400,.001*factor),(2400,5150,.002*factor),
            (5150,16000,.02*factor),(16000,26000,.2*factor)]

def continuum(nu,T,P,x):
    with Dataset(DATA/'absco-ref_wv-mt-ckd.nc') as f:
        w=f['wavenumbers'][:]; t0=float(f['ref_temp'][:]);p0=float(f['ref_press'][:])
        dens=P/100/p0*t0/T
        rad=w*np.tanh(C2*w/(2*T))
        a=f['self_absco_ref'][:]*(t0/T)**f['self_texp'][:]*x*dens*rad
        b=f['for_absco_ref'][:]*(1-x)*dens*rad
    return np.maximum(0,np.interp(nu,w,a+b,left=0,right=0))

def cross_section(start,step,count,d,T,P,x,name,cutoff=1e-28,wing=25.):
    mol={'H2O':1,'CO2':2}[name]
    keep=(d['S']>=cutoff)&(d['nu']>=start-wing)&(d['nu']<=start+step*count+wing)
    q={k:v[keep] for k,v in d.items()}
    ratio=np.empty(len(q['nu']))
    for iso in set(q['iso']):ratio[q['iso']==iso]=hapi.partitionSum(mol,int(iso),296.)/hapi.partitionSum(mol,int(iso),float(T))
    S=q['S']*ratio*np.exp(-C2*q['E']*(1/T-1/296.))
    S*=np.expm1(-C2*q['nu']/T)/np.expm1(-C2*q['nu']/296.)
    ga=np.where(q['ga']>0,q['ga'],.07); gs=np.where(q['gs']>0,q['gs'],ga)
    gamma=((1-x)*ga+x*gs)*(P/101325.)*(296/T)**q['n']
    sigma=q['nu']/C*np.sqrt(KB*T/(q['mass']*1.66053906660e-27))
    center=q['nu']+q['shift']*(P/101325.)*(1-x)
    return line_sum(start,step,count,center,S,sigma,gamma,wing,name=='H2O')

def profile(key='tropical',dz=2.):
    mapping={'tropical':'1a','mid_summer':'1b','mid_winter':'1c','subarctic_summer':'1d','subarctic_winter':'1e','us_standard':'1f'}
    p=np.genfromtxt(DATA/f'afgl_{mapping[key]}.csv',delimiter=',',names=True)
    z=np.unique(np.r_[np.arange(0,60.001,dz),np.arange(60,80.001,5)])
    mid=(z[:-1]+z[1:])/2
    pressure=np.exp(np.interp(z,p['z'],np.log(p['p'])))*100
    pmid=np.sqrt(pressure[:-1]*pressure[1:]);T=np.interp(mid,p['z'],p['t'])
    x=np.exp(np.interp(mid,p['z'],np.log(p['H2O']*1e-6)))
    # Approximate dry-air column from hydrostatic mass; fixed mean molar mass.
    N=(pressure[:-1]-pressure[1:])/G/M_AIR*NA/1e4
    # AFGL table tropopause proxy: lowest T in the lower 25 km, rounded to grid interface.
    trop=float(z[np.argmin(np.interp(z[z<=25],p['z'],p['t']))])
    return dict(z=z,mid=mid,p=pressure,pmid=pmid,T=T,x=x,N=N,trop=trop)

def solar(nu):
    # TOA spectrum, never the atmosphere-transmitted ASTM columns.
    full=np.genfromtxt(DATA/'solar_full.csv',delimiter=',',skip_header=1)
    with Dataset(DATA/'solar_1nm.nc') as f:w=f['Vacuum Wavelength'][:];e=f['SSI'][:]
    lam=1e7/nu
    b=np.interp(lam,full[:,0],full[:,1],left=0,right=0)
    inside=(lam>=w.min())&(lam<=w.max());b[inside]=np.interp(lam[inside],w,e)
    return b*1e7/nu**2

def rayleigh(nu,N):
    # Common visible/NIR air optical depth law; extrapolation outside its main validity range.
    lam=1e4/nu
    tau=.008569*lam**(-4)*(1+.0113/lam**2+.00013/lam**4)
    Nstd=101325/G/M_AIR*NA/1e4
    return N[:,None]/Nstd*tau[None,:]

def layer_rt(tau_abs,tau_sc,mu0):
    tau=tau_abs+tau_sc
    omega=np.divide(tau_sc,tau,out=np.zeros_like(tau),where=tau>0)
    mud=1/np.sqrt(3.);a=(1-omega/2)/mud;b=omega/(2*mud)
    k=np.sqrt(np.maximum(0,a*a-b*b));v=k*tau
    e=np.exp(-v);e2=e*e;den=(k+a)+(k-a)*e2
    R=np.divide(b*(1-e2),den,out=np.zeros_like(den),where=den!=0)
    Tr=np.divide(2*k*e,den,out=np.ones_like(den),where=den!=0)
    conservative=k<1e-7
    R=np.where(conservative,b*tau/(1+a*tau),R)
    Tr=np.where(conservative,1/(1+a*tau),Tr)
    r=1/mu0;det=r*r-k*k;det=np.where(abs(det)<1e-9,1e-9,det)
    q=omega/(2*mu0)
    u0=-q*(r+a+b)/det;u1=q*(r-a-b)/det
    edir=np.exp(-r*tau)
    su=u1-R*u0-Tr*u1*edir
    sd=u0*edir-Tr*u0-R*u1*edir
    # Numerical cancellation at very small optical depth can produce tiny negative sources.
    su=np.maximum(0,su);sd=np.maximum(0,sd)
    return R,Tr,su,sd,edir

def solve_sw(tabs,tsc,E,mu0,albedo):
    # Input bottom-to-top profile; transfer solver top-to-bottom.
    R,T,su,sd,edir=layer_rt(tabs[::-1],tsc[::-1],mu0)
    n,m=tabs.shape
    B=np.empty((n+1,m));B[0]=mu0*E
    for j in range(n):B[j+1]=B[j]*edir[j]
    A=np.empty_like(B);b=np.empty_like(B);A[n]=albedo;b[n]=albedo*B[n]
    for j in range(n-1,-1,-1):
        d=1-R[j]*A[j+1]
        A[j]=R[j]+T[j]*T[j]*A[j+1]/d
        b[j]=T[j]*(b[j+1]+A[j+1]*sd[j]*B[j])/d+su[j]*B[j]
    D=np.zeros_like(B)
    for j in range(n):D[j+1]=(T[j]*D[j]+R[j]*b[j+1]+sd[j]*B[j])/(1-R[j]*A[j+1])
    U=A*D+b
    return (D+B-U)[::-1],B[::-1],D[::-1],U[::-1]

def optics_cache(key,lo,hi,step,cutoff,wing,dz):
    p=profile(key,dz); CACHE.mkdir(parents=True,exist_ok=True)
    ident=f'{key}_{lo}_{hi}_{step:.7f}_{cutoff:.1e}_{wing}_{dz}'
    name=CACHE/(ident+'_ped25.npz')
    if name.exists():
        with np.load(name) as f:return p,f['co2'],f['h2o']
    old=CACHE/(ident+'.npz')
    if old.exists() and wing<=25.:
        with np.load(old) as f:co2=f['co2'];water=f['h2o']
        count=co2.shape[1];start=lo+step/2;d=parse_lines('H2O')
        keep=(d['S']>=cutoff)&(d['nu']>=start-wing)&(d['nu']<=start+step*count+wing)
        q={k:v[keep] for k,v in d.items()}
        for j,(t,pressure,x,N) in enumerate(zip(p['T'],p['pmid'],p['x'],p['N'])):
            ratio=np.empty(len(q['nu']))
            for iso in set(q['iso']):ratio[q['iso']==iso]=hapi.partitionSum(1,int(iso),296.)/hapi.partitionSum(1,int(iso),float(t))
            S=q['S']*ratio*np.exp(-C2*q['E']*(1/t-1/296.))*np.expm1(-C2*q['nu']/t)/np.expm1(-C2*q['nu']/296.)
            ga=np.where(q['ga']>0,q['ga'],.07);gs=np.where(q['gs']>0,q['gs'],ga)
            gamma=((1-x)*ga+x*gs)*pressure/101325.*(296/t)**q['n']
            sigma=q['nu']/C*np.sqrt(KB*t/(q['mass']*1.66053906660e-27))
            center=q['nu']+q['shift']*pressure/101325.*(1-x)
            water[j]+=old_pedestal_correction(start,step,count,center,S,sigma,gamma,wing)*N*x
        np.savez(name,co2=co2,h2o=water)
        return p,co2,water
    count=int(round((hi-lo)/step));nu=lo+(np.arange(count)+.5)*step
    co2=np.empty((len(p['T']),count),np.float32);water=np.empty_like(co2)
    dc=parse_lines('CO2');dw=parse_lines('H2O')
    for j,(t,pressure,x,N) in enumerate(zip(p['T'],p['pmid'],p['x'],p['N'])):
        co2[j]=cross_section(nu[0],step,count,dc,t,pressure,.00028,'CO2',cutoff,wing)*N*1e-6
        water[j]=(cross_section(nu[0],step,count,dw,t,pressure,x,'H2O',cutoff,wing)+continuum(nu,t,pressure,x))*N*x
    np.savez(name,co2=co2,h2o=water)
    return p,co2,water

def run(key='tropical',factor=1.,cutoff=1e-28,wing=25.,dz=2.,extra=True):
    print('RUN',key,factor,cutoff,wing,dz,flush=True);start=time.time()
    p=profile(key,dz); n=len(p['T'])
    # Geometry: a fixed 60-degree solar zenith angle over half the time.
    # No claim that this replaces annual geographic integration.
    configs=[(c,1.,.06,'base') for c in [278,280,417,420,560,1120]]
    if extra:
        configs += [(c,water,albedo,label) for water,albedo,label in
                    [(0.,.06,'dry'),(.5,.06,'half_water'),(1.5,.06,'wet'),(1.,.2,'land'),(1.,.8,'snow')]
                    for c in [280,420,560,1120]]
    flux=np.zeros((len(configs),4,n+1));gas_abs=np.zeros((len(configs),2,n));spec=[]
    for lo,hi,step in grid_segments(factor):
        print(' segment',lo,hi,'step',step,flush=True)
        p,tc,tw=optics_cache(key,lo,hi,step,cutoff,wing,dz)
        count=tc.shape[1];nu=lo+(np.arange(count)+.5)*step
        sun=solar(nu)
        # Use spectral chunks to bound solver working memory.
        for left in range(0,count,12000):
            right=min(count,left+12000);v=nu[left:right];E=sun[left:right]
            scat=rayleigh(v,p['N']); cs=tc[:,left:right].astype(float);ws=tw[:,left:right].astype(float)
            block=[];blockgas=[]
            for k,(conc,water,albedo,label) in enumerate(configs):
                tabs=cs*conc+ws*water
                ff=solve_sw(tabs,scat,E,.5,albedo)
                for j in range(4):flux[k,j]+=ff[j].sum(axis=1)*step*.5
                absorbed=np.diff(ff[0],axis=0)
                share=np.divide(cs*conc,tabs,out=np.zeros_like(tabs),where=tabs>0)
                gas_abs[k,0]+=(absorbed*share).sum(axis=1)*step*.5
                gas_abs[k,1]+=(absorbed*(1-share)).sum(axis=1)*step*.5
                if label=='base' and conc in [280,420]:
                    block.append(ff[0]);blockgas.append((absorbed*share).sum(axis=0))
            # Output 10-cm^-1 bins, with exact within-bin sum, for two controls.
            groups=(v/10).astype(int)
            for group in np.unique(groups):
                mask=groups==group
                # same bin may straddle a chunk; aggregate later
                spec.append((group,float((E[mask]*step*.25).sum()),
                  float((block[1][0,mask]-block[0][0,mask]).sum()*step*.5),
                  float(((block[1][-1,mask]-block[1][0,mask])-(block[0][-1,mask]-block[0][0,mask])).sum()*step*.5),
                  float((blockgas[1][mask]-blockgas[0][mask]).sum()*step*.5)))
        del tc,tw
    rows=[];prof=[]
    pairs=[(278,417),(280,420),(420,560),(280,560),(280,1120)]
    for water,albedo,label in sorted(set((c[1],c[2],c[3]) for c in configs)):
        for c0,c1 in pairs:
            inds=[i for i,c in enumerate(configs) if c==(c0,water,albedo,label)]
            ends=[i for i,c in enumerate(configs) if c==(c1,water,albedo,label)]
            if not inds or not ends:continue
            f=flux[ends[0]]-flux[inds[0]]
            net,direct,diffuse,up=f
            abs_layer=net[1:]-net[:-1]
            gas=gas_abs[ends[0]]-gas_abs[inds[0]]
            trop_mask=p['mid']<p['trop']
            row=dict(profile=key,kind=label,c0=c0,c1=c1,water_scale=water,albedo=albedo,
                     surface=float(net[0]),atmosphere=float(net[-1]-net[0]),toa=float(net[-1]),
                     reflected=float(up[-1]),troposphere=float(abs_layer[trop_mask].sum()),
                     above_tropopause_to80=float(abs_layer[~trop_mask].sum()),
                     direct_surface=float(direct[0]),diffuse_surface=float(diffuse[0]),
                     co2_absorption=float(gas[0].sum()),water_absorption=float(gas[1].sum()),
                     tropopause_km=p['trop'],closure=float(net[-1]-net[0]-abs_layer.sum()))
            rows.append(row)
            for j,q in enumerate(abs_layer):
                prof.append(dict(profile=key,kind=label,c0=c0,c1=c1,z0=p['z'][j],z1=p['z'][j+1],
                                 p_hpa=p['pmid'][j]/100,delta_absorption=float(q),
                                 delta_co2_absorption=float(gas[0,j]),delta_water_absorption=float(gas[1,j]),
                                 delta_heating_K_day=float(q*G/(CP*(p['p'][j]-p['p'][j+1]))*86400)))
    from collections import defaultdict
    bins=defaultdict(lambda:np.zeros(4))
    for g,*v in spec:bins[g]+=v
    spectra=[dict(nu_cm1=int(g*10+5),lambda_um=1e4/(g*10+5),toa_solar_Wm2=v[0],
                  delta_surface_Wm2=v[1],delta_atmosphere_Wm2=v[2],delta_co2_absorption_Wm2=v[3]) for g,v in sorted(bins.items())]
    states=[dict(c=conf[0],water_scale=conf[1],albedo=conf[2],kind=conf[3],z_km=p['z'].tolist(),
                 net_SW=flux[k,0].tolist(),direct_SW=flux[k,1].tolist(),diffuse_SW=flux[k,2].tolist(),up_SW=flux[k,3].tolist())
            for k,conf in enumerate(configs)]
    result=dict(rows=rows,profiles=prof,spectra=spectra,states=states,seconds=time.time()-start,
                config=dict(factor=factor,cutoff=cutoff,wing=wing,dz=dz,water_line_pedestal_cm1=25,solar_zenith_deg=60,day_fraction=.5,
                            omissions=['O3,O2,CH4,N2O absorption','CO2 line mixing/sub-Lorentz wings/CIA',
                                       'clouds and aerosols','LW temperature adjustment','climate dynamics']),
                incident_SW_Wm2=float(sum(v[0] for v in bins.values())))
    tag=f'{key}_f{factor}_s{cutoff:.0e}_w{wing}_dz{dz}'
    (RESULT/(tag+'.json')).write_text(json.dumps(result,indent=2))
    print('DONE',tag,'seconds',result['seconds'],'main',rows[0],flush=True)
    return result

def tests():
    rng=np.random.default_rng(1834)
    x=np.r_[np.linspace(-15,15,500),rng.normal(0,50,1000)]
    worst=0.
    for s in [.0004,.003,.02]:
        for g in [1e-6,.0005,.01,.1]:
            ref=wofz((x+1j*g)/(s*np.sqrt(2))).real/(s*np.sqrt(2*np.pi))
            calc=np.array([voigt(v,s,g) for v in x]); mask=ref>1e-10
            worst=max(worst,float(np.max(abs(calc[mask]/ref[mask]-1))))
    # The relative tail error is <1e-4; record the observed maximum explicitly.
    assert worst<1e-4,worst
    E=np.ones(500);sc=np.repeat(np.logspace(-8,3,500)[None,:],4,axis=0)
    net,*_=solve_sw(np.zeros_like(sc),sc,E,.5,.8)
    err=float(np.max(abs(net-net[0])))
    assert err<1e-9,err
    ab=np.repeat(np.logspace(-8,6,500)[None,:],4,axis=0)
    net,B,D,U=solve_sw(ab,np.zeros_like(ab),E,.5,0.)
    assert np.max(abs(D))<1e-12 and np.max(abs(U))<1e-12
    assert np.max(abs(net-B))<1e-12
    # Exact Beer-Lambert case and absorbing Lambertian surface.
    net,B,D,U=solve_sw(ab,np.zeros_like(ab),E,.5,.3)
    assert np.max(abs(net[0]-.7*B[0]))<1e-12
    assert np.min(np.diff(net,axis=0))>=-1e-12
    out=dict(voigt_max_relative_error=worst,conservative_scattering_flux_error_Wm2=err,
             beer_lambert='passed',surface_absorption='passed',monotone_absorption='passed')
    (RESULT/'tests.json').write_text(json.dumps(out,indent=2));print(out,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--profile',default='tropical')
    parser.add_argument('--factor',type=float,default=1.);parser.add_argument('--cutoff',type=float,default=1e-28)
    parser.add_argument('--wing',type=float,default=25.);parser.add_argument('--dz',type=float,default=2.)
    parser.add_argument('--tests',action='store_true');parser.add_argument('--base-only',action='store_true')
    args=parser.parse_args();RESULT.mkdir(exist_ok=True)
    if args.tests:tests()
    else:run(args.profile,args.factor,args.cutoff,args.wing,args.dz,not args.base_only)
