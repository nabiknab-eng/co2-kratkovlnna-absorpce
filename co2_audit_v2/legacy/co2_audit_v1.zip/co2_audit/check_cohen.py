"""Check saved author output, not a re-run or an instantaneous CO2 experiment."""
from pathlib import Path
import json, hashlib
import numpy as np
from netCDF4 import Dataset
ROOT=Path(__file__).resolve().parent
out={}
base=None
for conc in [280,560,1120]:
    path=ROOT/'data'/'cohen'/f'287K_{conc}.0ppm.nc'
    with Dataset(path) as f:
        rad=f['radiation'];atm=f['atmosphere']
        d={k:np.asarray(rad[k][:]) for k in ['sw_htngrt','sw_flxd','sw_flxu']}
        if base is None:base=d
        out[str(conc)]={k:float(np.max(abs(v-base[k]))) for k,v in d.items()}
        out[str(conc)].update(CO2_min=float(np.min(atm['CO2'][:])),CO2_max=float(np.max(atm['CO2'][:])),
          heating_unit=getattr(rad['sw_htngrt'],'units','unspecified'),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
(ROOT/'results'/'cohen_data_check.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
