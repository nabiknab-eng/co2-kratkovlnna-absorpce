"""Public data download. The delivered private archive already includes inputs.

HITRAN .par files are account-dependent exports. Preserve supplied snapshots;
this script never handles credentials or labels live exports as a frozen edition.
"""
from pathlib import Path
import urllib.request, hashlib, json, argparse, shutil, zipfile, io
ROOT=Path(__file__).resolve().parent;DATA=ROOT/'data'
urls={
 'solar_1nm.nc':'https://lasp.colorado.edu/lisird/resources/lasp/hsrs/v2/hybrid_reference_spectrum_1nm_resolution_c2022-11-30_with_unc.nc',
 'solar_full.csv':'https://lasp.colorado.edu/lisird/latis/dap/tsis1_hsrs_binned_fs.csv',
 'absco-ref_wv-mt-ckd.nc':'https://raw.githubusercontent.com/AER-RC/MT_CKD_H2O/master/data/absco-ref_wv-mt-ckd.nc',
 **{f'afgl_{x}.csv':f'https://raw.githubusercontent.com/rayference/afgl1986/main/tables/{x}.csv' for x in ['1a','1b','1c','1d','1e','1f']}}

def main():
    p=argparse.ArgumentParser();p.add_argument('--hitran-dir');p.add_argument('--cohen',action='store_true');a=p.parse_args()
    DATA.mkdir(exist_ok=True)
    for name,url in urls.items():
        dest=DATA/name
        if not dest.exists():dest.write_bytes(urllib.request.urlopen(url,timeout=120).read())
        print(name,hashlib.sha256(dest.read_bytes()).hexdigest())
    if a.hitran_dir:
        for mol in ['CO2','H2O']:shutil.copy2(Path(a.hitran_dir)/f'{mol}_HITRAN.par',DATA/f'{mol}_HITRAN.par')
    if a.cohen:
        url='https://zenodo.org/api/records/16929030/files/co2_strat_adjust-co2_strat_adjust.zip/content'
        raw=urllib.request.urlopen(url,timeout=180).read();target=DATA/'cohen';target.mkdir(exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for n in z.namelist():
                if n.split('/')[-1] in [f'287K_{c}.0ppm.nc' for c in [280,560,1120]]:
                    (target/n.split('/')[-1]).write_bytes(z.read(n))

if __name__=='__main__':main()
