"""Nontrivial solver tests plus consistency/sign/unit checks of saved experiments."""
from pathlib import Path
import json
from model import tests
ROOT=Path(__file__).resolve().parent
tests()
worst={k:0. for k in ['surface','toa','layers','species','spectrum']};count=0
for path in (ROOT/'results').glob('*_f*.json'):
    d=json.loads(path.read_text())
    for r in d['rows']:
        worst['surface']=max(worst['surface'],abs(r['surface']-(1-r['albedo'])*(r['direct_surface']+r['diffuse_surface'])))
        worst['toa']=max(worst['toa'],abs(r['toa']+r['reflected']))
        worst['layers']=max(worst['layers'],abs(r['atmosphere']-r['troposphere']-r['above_tropopause_to80']))
        if 'co2_absorption' in r:worst['species']=max(worst['species'],abs(r['atmosphere']-r['co2_absorption']-r['water_absorption']))
        count+=1
    r=next(r for r in d['rows'] if r['kind']=='base' and r['c0']==280 and r['c1']==420)
    worst['spectrum']=max(worst['spectrum'],abs(r['surface']-sum(s['delta_surface_Wm2'] for s in d['spectra'])))
assert max(worst.values())<1e-6,worst
(ROOT/'results'/'verification.json').write_text(json.dumps(dict(saved_rows_checked=count,max_residuals_Wm2=worst),indent=2))
print(count,worst)
