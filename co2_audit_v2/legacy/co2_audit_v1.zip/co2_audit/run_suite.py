"""Execute the documented finite suite. Coarse sensitivity tests are labeled."""
from pathlib import Path
import os, sys, subprocess, json
ROOT=Path(__file__).resolve().parent
profiles=['tropical','mid_summer','mid_winter','subarctic_summer','subarctic_winter','us_standard']
configs=[dict(profile=k,factor=10,cutoff=1e-25,wing=5,dz=8,base_only=True) for k in profiles]
(ROOT/'suite_coarse.json').write_text(json.dumps(configs,indent=2))
for c in configs:
    tag=f"{c['profile']}_f{float(c['factor'])}_s{c['cutoff']:.0e}_w{float(c['wing'])}_dz{float(c['dz'])}"
    target=ROOT/'results'/(tag+'.json')
    if target.exists() and json.loads(target.read_text())['config'].get('water_line_pedestal_cm1')==25:continue
    args=[sys.executable,'-u',str(ROOT/'model.py')]
    for k,v in c.items():
        if k=='base_only':
            if v:args+=['--base-only']
        else:args+=['--'+k,str(v)]
    subprocess.run(args,check=True)
