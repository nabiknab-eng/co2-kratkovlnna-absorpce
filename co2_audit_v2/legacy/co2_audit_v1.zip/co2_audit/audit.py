"""Arithmetic checks of published values, not a re-run of SOCRATES/CESM2."""
from pathlib import Path
import json, csv, math
ROOT=Path(__file__).resolve().parent
RESULT=ROOT/'results'

def main():
    # Shine et al. (2022), Table 3. Entries transcribed from the publisher's HTML.
    Q=.07-(-.12)
    dLWtop=2.07-2.19; dLWbottom=2.26-2.19
    swtop=.07+dLWtop; swbottom=-.12+dLWbottom
    assert abs(Q+dLWtop-dLWbottom)<1e-12
    assert abs(swtop-swbottom)<1e-12
    Ftotal=2.14;Flw=2.19
    assert abs((Ftotal-Flw)-swtop)<1e-12
    # The CI calculation below is purely illustrative. Do not infer raw sample variance.
    out=dict(shine=dict(delta_strat_SW_absorption=Q,delta_OLR_due_to_SW=-dLWtop,
      delta_downward_LW_tropopause_due_to_SW=dLWbottom,SW_induced_net_forcing=swtop,
      fractional_reduction=100*(Flw-Ftotal)/Flw,
      outward_fraction_of_differential_strat_radiative_cooling=-dLWtop/Q,
      upward_downward_differential_LW_ratio=-dLWtop/dLWbottom,
      decimal_rounding_bound_net_difference_Wm2=.01,
      scope='January global mean, 278 to 417 ppm, published rounded fluxes; no surface flux provided'),
      boundary_layer_illustration=dict(h_m=1000,rho_kgm3=1.2,cp_JkgK=1004.,
       dQ_Wm2=-1.,K_per_day=-86400/(1.2*1000*1004.),
       scope='Closed-box heat-capacity illustration; not a CO2 temperature prediction'),
      allen=dict(T_4x_SW_K=-.38,CI90_K=.12,ERF_2x_SW_Wm2=-.03,CI90_ERF_2x=.15,
                 ERF_4x_SW_Wm2=-.35,CI90_ERF_4x=.15,
                 coupled_2x_CO2='not performed in this paper',
                 scope='Published model outputs; not independently reproduced'))
    (RESULT/'publication_audit.json').write_text(json.dumps(out,indent=2))
    # Explore sign without assigning a final destination to individual photons.
    with (RESULT/'analytic_stratosphere.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['fraction_of_differential_LW_cooling_upward','SW_induced_net_forcing_Wm2'])
        for i in range(101):w.writerow([i/100,.07-i/100*.19])
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
