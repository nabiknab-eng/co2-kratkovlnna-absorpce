"""Build an offline Czech report and figures from computed JSON files."""
from pathlib import Path
import json, csv, html, io, base64, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

ROOT=Path(__file__).resolve().parent;RES=ROOT/'results';FIG=ROOT/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
 'axes.spines.right':False,'svg.fonttype':'none','axes.labelcolor':'#213947',
 'text.color':'#213947','axes.edgecolor':'#9aaab2','grid.alpha':.2})
TEAL='#087f83'; BLUE='#2b5e9e'; ORANGE='#b86b1b'; GRAY='#6e7f89'

def read(name):return json.loads((RES/name).read_text())
primary=read('tropical_f5.0_s1e-26_w25.0_dz4.0.json')
old=read('tropical_f5.0_s1e-26_w10.0_dz4.0.json')
audit=read('publication_audit.json');cohen=read('cohen_data_check.json')
def row(d=primary,c0=280,c1=420,kind='base'):
    return next(r for r in d['rows'] if r['c0']==c0 and r['c1']==c1 and r['kind']==kind)
r=row()
def num(x,d=3,sign=False):
    if isinstance(x,str):return x
    return format(float(x),('+' if sign else '')+f'.{d}f').replace('.',',').replace('-','−')
def table(head,rows,cls=''):
    return '<div class="table-scroll"><table class="'+cls+'"><thead><tr>'+''.join('<th scope="col">'+str(h)+'</th>' for h in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(c)+'</td>' for c in rr)+'</tr>' for rr in rows)+'</tbody></table></div>'
def eq(s):return '<div class="equation">'+s+'</div>'
def note(s,title='Jak toto číslo číst'):
    return '<aside class="note"><strong>'+title+'</strong><p>'+s+'</p></aside>'

def savefig(name,fig,caption):
    fig.tight_layout(pad=1.5);fig.savefig(FIG/(name+'.svg'),bbox_inches='tight');plt.close(fig)
    s=(FIG/(name+'.svg')).read_text();s=s[s.index('<svg'):]
    s=s.replace('<svg ',f'<svg role="img" aria-label="{html.escape(caption,quote=True)}" ',1)
    return '<figure>'+s+'<figcaption>'+caption+'</figcaption></figure>'

sp=primary['spectra'];nu=np.array([s['nu_cm1'] for s in sp]);lam=1e4/nu
dl=1e4/(nu-5)-1e4/(nu+5);order=np.argsort(lam)
fig,ax=plt.subplots(figsize=(9,3.8))
for k,label,color in [('delta_co2_absorption_Wm2','Přímo CO₂',TEAL),('delta_atmosphere_Wm2','Celá atmosféra (CO₂ + H₂O)',ORANGE)]:
    ax.plot(lam[order],np.array([s.get(k,0) for s in sp])[order]/dl[order],lw=1.2,label=label,color=color)
ax.set(xlim=(.65,5.5),xlabel='Vlnová délka (µm)',ylabel='Změna absorpce (W/m²/µm)');ax.axhline(0,color=GRAY,lw=.6);ax.legend();ax.grid()
f1=savefig('01_spektralni_absorpce',fig,'1. Vlastní výpočet 280 → 420 ppm: změna přímé absorpce CO₂ a změna absorpce celé atmosféry. Křivky se liší kvůli vytěsnění části absorpce H₂O; zobrazeny integrály v buňkách 10 cm⁻¹, převedené na hustotu podle vlnové délky.')
fig,ax=plt.subplots(figsize=(9,3.5));ax.plot(lam[order],np.array([s['delta_surface_Wm2'] for s in sp])[order]/dl[order],color=TEAL,lw=1.2)
ax.set(xlim=(.65,5.5),xlabel='Vlnová délka (µm)',ylabel='Změna příkonu povrchu (W/m²/µm)');ax.axhline(0,color=GRAY,lw=.7);ax.grid()
f2=savefig('02_spektrum_povrch',fig,'2. Vlastní výpočet: záporná změna znamená menší krátkovlnný tok absorbovaný povrchem. Jde o sluneční záření, i když část zobrazených vlnových délek leží v infračervené oblasti.')
pp=[p for p in primary['profiles'] if p['kind']=='base' and p['c0']==280 and p['c1']==420]
z=np.array([(p['z0']+p['z1'])/2 for p in pp]);h=np.array([p['z1']-p['z0'] for p in pp])
fig,ax=plt.subplots(figsize=(7.5,4.5));ax.barh(z,[p['delta_absorption'] for p in pp],height=h*.84,color=TEAL)
ax.axhline(r['tropopause_km'],ls='--',color=ORANGE,label='Modelová hranice 16 km');ax.axvline(0,color=GRAY,lw=.5)
ax.set(xlabel='Změna absorpce celé vrstvy (W/m²)',ylabel='Výška (km)',ylim=(0,80));ax.legend();ax.grid(axis='x')
f3=savefig('03_vyska_absorpce',fig,'3. Vlastní změna absorpce celé atmosféry po vrstvách. Tloušťka vrstev je 4 km do 60 km a 5 km nad touto výškou. Hranice 16 km je modelová tropopauza, nikoli horní hranice přízemní mezní vrstvy.')
fig,ax=plt.subplots(figsize=(7.5,4.5));ax.plot([p['delta_heating_K_day'] for p in pp],z,'o-',color=TEAL,ms=3)
ax.axhline(16,ls='--',color=ORANGE);ax.axvline(0,color=GRAY,lw=.5);ax.set(xlabel='Změna krátkovlnného ohřevu (K/den)',ylabel='Výška (km)',ylim=(0,80));ax.grid()
f4=savefig('04_radialni_ohrev',fig,'4. Vlastní okamžitá změna rychlosti krátkovlnného radiačního ohřevu. K/den je energetický přepočet pro pevný stav atmosféry; tento graf neudává předpověď vývoje její teploty.')
fig,axes=plt.subplots(1,2,figsize=(10,3.8))
axes[0].bar(['Absorpce SW','LW do vesmíru','LW dolů'],[.19,-.12,-.07],color=[ORANGE,TEAL,BLUE]);axes[0].set(ylabel='Příspěvek k bilanci stratosféry (W/m²)',title='Bilanční kontrola publikované tabulky');axes[0].axhline(0,color=GRAY,lw=.6)
axes[1].bar(['Přímý SW na TOA','Změna LW na TOA','Součet'],[.07,-.12,-.05],color=[ORANGE,TEAL,BLUE]);axes[1].set(ylabel='Změna čistého toku dolů (W/m²)',title='Příspěvek vyvolaný SW procesy');axes[1].axhline(0,color=GRAY,lw=.6)
for a in axes:a.tick_params(axis='x',labelrotation=12);a.grid(axis='y')
f5=savefig('05_shine_bilance',fig,'5. Náš aritmetický rozklad zaokrouhlených údajů Shine et al. (2022), tabulka 3, 278 → 417 ppm, globální lednový průměr. Toto je kontrola publikovaných toků, nikoli vlastní simulace dlouhovlnné adaptace.')
fig,ax=plt.subplots(figsize=(8.5,3.8));cs=np.array([280,420,560,1120]);vals=np.r_[0,[row(c1=int(c))['surface'] for c in cs[1:]]]
ax.plot(cs,vals,'o-',color=TEAL,label='Vlastní vypočtené body');cc=np.linspace(280,1120,200)
ax.plot(cc,vals[2]/np.log(2)*np.log(cc/280),'--',color=ORANGE,label='Logaritmická křivka ukotvená v 560 ppm')
ax.set(xlabel='CO₂ (ppm)',ylabel='Změna SW absorpce povrchu vůči 280 ppm (W/m²)');ax.grid();ax.legend()
f6=savefig('06_koncentrace',fig,'6. Vypočtené koncentrace a kontrolní logaritmická křivka. Spojnice bodů je grafická pomůcka; nebyla provedena souvislá hustá koncentrační simulace. Čistě logaritmická závislost zde není přesná.')
fig,ax=plt.subplots(figsize=(8.5,3.7));ks=['dry','half_water','base','wet'];labs=['Bez H₂O','0,5 × H₂O','Referenční H₂O','1,5 × H₂O']
ax.bar(labs,[row(kind=k)['surface'] for k in ks],color=[GRAY,BLUE,TEAL,ORANGE]);ax.set(ylabel='Změna SW absorpce povrchu (W/m²)');ax.axhline(0,color=GRAY,lw=.6);ax.grid(axis='y')
f7=savefig('07_vodni_para',fig,'7. Vlastní citlivost na obsah vodní páry při stejném tlaku a teplotě, 280 → 420 ppm. Při škálování H₂O se škáluje její předpočítaná optická tloušťka; vlastní šířky čar se znovu neurčují.')
names={'tropical':'Tropy','mid_summer':'Střední šířky – léto','mid_winter':'Střední šířky – zima','subarctic_summer':'Subarktida – léto','subarctic_winter':'Subarktida – zima','us_standard':'US standard'}
coarse=[]
for key in names:
    path=RES/f'{key}_f10.0_s1e-25_w5.0_dz8.0.json'
    if path.exists():coarse.append((key,row(read(path.name))))
fig,ax=plt.subplots(figsize=(9,4));ax.barh([names[k] for k,v in coarse],[v['surface'] for k,v in coarse],color=TEAL);ax.set(xlabel='Změna SW absorpce povrchu (W/m²)');ax.grid(axis='x')
f8=savefig('08_profily',fig,'8. Vlastní orientační srovnání šesti AFGL profilů ve stejné hrubší konfiguraci. Jejich nevyvážený průměr nepředstavuje roční globální výsledek. Subarktická zima slouží pouze jako chladný suchý zástupný profil, nikoli jako úplná polární klimatologie.')
fig,ax=plt.subplots(figsize=(8.5,3.8));x=np.linspace(0,1,200);ax.plot(x,.07-.19*x,color=TEAL);ax.axhline(0,color=GRAY);ax.axvline(.07/.19,color=ORANGE,ls='--',label='Změna znaménka: f = 0,368')
ax.scatter([.12/.19],[-.05],color=BLUE,zorder=3,label='Poměr odvozený z tabulky Shine');ax.set(xlabel='Podíl diferenčního LW ochlazování stratosféry směrem vzhůru f',ylabel='SW vyvolaný čistý účinek na TOA (W/m²)');ax.grid();ax.legend()
f9=savefig('09_analyticky_test',fig,'9. Vlastní analytický test ΔF = 0,07 − f × 0,19. Vstupní toky pocházejí z tabulky Shine; parametr f je měněn hypoteticky. Stejná zvýšená absorpce může podle radiační vazby stratosféry vést k různému znaménku čistého účinku.')
sens=[]
if (RES/'tropical_f2.5_s1e-26_w10.0_dz4.0.json').exists():sens.append(('Poloviční spektrální krok',row(read('tropical_f2.5_s1e-26_w10.0_dz4.0.json'))['surface']-row(old)['surface']))
sens.append(('Křídla 10 → 25 cm⁻¹',r['surface']-row(old)['surface']))
if (RES/'tropical_f5.0_s1e-27_w10.0_dz4.0.json').exists():sens.append(('Práh intenzity 10⁻²⁶ → 10⁻²⁷',row(read('tropical_f5.0_s1e-27_w10.0_dz4.0.json'))['surface']-row(old)['surface']))
fig,ax=plt.subplots(figsize=(9,3.7));ax.barh([s[0] for s in sens],[s[1] for s in sens],color=TEAL);ax.axvline(0,color=GRAY,lw=.7);ax.set(xlabel='Změna vypočteného příkonu povrchu po změně nastavení (W/m²)');ax.grid(axis='x')
f10=savefig('10_numericka_citlivost',fig,'10. Vlastní změny vždy jednoho numerického nastavení při 280 → 420 ppm. Nejde o rozklad celkové fyzikální nejistoty ani o interval spolehlivosti; chybí zde například nejistota oblačnosti a spektrálních parametrů.')

sections=[];toc=[]
def add(id,title,body):
    toc.append((id,title));sections.append(f'<section id="{id}" aria-labelledby="h-{id}"><h2 id="h-{id}">{title}</h2>{body}</section>')

add('uvod','Nejprve jednoduše: co zde zkoumáme',f'''
<p class="lead"><strong>Více CO₂ může v některých částech slunečního spektra zachytit více energie už v atmosféře. Na zemský povrch pak dopadne méně této energie, povrch se méně ohřívá a může předávat méně tepla vzduchu těsně nad sebou.</strong> Právě tento dílčí mechanismus může přispívat k omezení ohřevu, případně k ochlazení přízemní mezní vrstvy oproti situaci bez dodatečné krátkovlnné absorpce CO₂.</p>
<p>Výraz <strong>ochlazující příspěvek</strong> zde znamená změnu vůči přesně určenému srovnávacímu stavu. Například povrch, který se po zahrnutí všech účinků ohřeje, se může vlivem tohoto jednoho procesu ohřát o něco méně. Ke zjištění příspěvku porovnáváme jinak shodné výpočty, v nichž se liší krátkovlnný účinek CO₂.</p>
<div class="steps"><div><b>1</b><h3>Slunce dodá energii</h3><p>Záření prochází atmosférou směrem k povrchu.</p></div><div><b>2</b><h3>CO₂ část pohltí dříve</h3><p>Část energie se uloží ve vzduchu nad povrchem.</p></div><div><b>3</b><h3>Povrch dostane menší příkon</h3><p>Může následovat slabší ohřev povrchu a přízemního vzduchu.</p></div></div>
<h3>1. Proč jde o jiný účinek než známé zadržování tepla</h3>
<p>Slunce a Země vyzařují převážně na jiných vlnových délkách. Sluneční záření přichází hlavně ve viditelné a přilehlé infračervené oblasti. Zemský povrch a atmosféra vyzařují převážně v delším tepelném infračerveném oboru. CO₂ reaguje na obě složky. U příchozího slunečního záření proto sledujeme, kolik energie se k povrchu vůbec dostane; u zemského tepelného záření sledujeme jeho výměnu mezi povrchem, atmosférou a vesmírem.</p>
<p>V této zprávě označujeme jako <strong>SW</strong> záření pocházející ze Slunce a jako <strong>LW</strong> tepelné záření vzniklé na Zemi a v její atmosféře. Rozhoduje původ záření. Sluneční a zemské spektrum se v části infračervené oblasti překrývají.</p>
<h3>2. Co jsou méně probíraná absorpční pásma CO₂</h3>
<p>Molekula CO₂ nepohlcuje všechny „barvy“ záření stejně. Má určité oblasti, v nichž může záření účinněji pohltit. Ty se nazývají <strong>absorpční pásma</strong> a při podrobném pohledu obsahují velké množství úzkých spektrálních čar. Ve slunečním infračerveném záření jsou relevantní například oblasti přibližně kolem 1,6; 2,0; 2,7 a 4,3 µm. Mikrometr, značený µm, je miliontina metru.</p>
<p>„Méně probíraná“ zde znamená méně obvyklá v jednoduchém veřejném vysvětlování CO₂. Nejde o nově objevenou vlastnost molekuly. Podstatné je přesně určit jejich přírůstkový účinek při zvýšení koncentrace a to, jak dobře jej konkrétní model zachycuje.</p>
<h3>3. Jak může pohlcování záření přispívat k ochlazení u země</h3>
<p>Povrch se obvykle zahřívá i tím, že pohltí sluneční záření. Následně předává energii vzduchu přímou výměnou tepla a pohybem vzduchu; část energie také spotřebuje na vypařování vody. Když se část slunečního příkonu zachytí už výše, může se snížit ohřev povrchu i jeho předávání citelného tepla do nejnižší atmosféry.</p>
<p><strong>Mezní vrstva</strong> je nejnižší část atmosféry, kterou výrazně ovlivňuje kontakt se zemským povrchem. Její hloubka se mění během dne a podle počasí. Není totožná s celou troposférou. <strong>Troposféra</strong> je podstatně hlubší spodní oblast atmosféry; nad její horní hranicí, tropopauzou, leží <strong>stratosféra</strong>.</p>
<h3>4. Kam se poděje energie, která nedopadne na zem</h3>
<p>Energie pohlcená CO₂ nezmizí. Absorpce představuje kladný příspěvek k ohřevu vrstvy, v níž nastala. Atmosféra však zároveň vyzařuje a vyměňuje si energii s okolím. Po změně teplot může část dodatečného radiačního výdeje směřovat k povrchu a část do vesmíru. Mohou se změnit i vodní pára, oblaky a proudění. Proto není možné celou ztrátu slunečního příkonu povrchu automaticky ztotožnit s čistým ochlazením celé planety.</p>
<p>Důležitá je výška absorpce. Energie pohlcená vysoko má jiné možnosti radiační výměny než energie pohlcená blízko povrchu. Zkoumáme tedy nejen <em>kolik</em> energie se zachytí, ale také <em>kde</em> a <em>jak se změní následné toky</em>.</p>
<h3>5. Proč záleží na vodní páře a oblacích</h3>
<p>V některých spektrálních oblastech už záření pohlcuje vodní pára. Přidaný CO₂ tam může část energie zachytit dříve, než by ji zachytila H₂O. Přímá absorpce CO₂ se tak může zvýšit výrazněji než součet absorpce celé atmosféry. V suchém vzduchu a ve vlhkém vzduchu proto nemusí vyjít stejný přírůstkový účinek.</p>
<p>Oblaky a světlý povrch navíc část slunečního záření vracejí vzhůru. Záření potom prochází některými vrstvami znovu. Tím se může měnit jeho absorpce i množství odražené do vesmíru. O znaménku čistého účinku nelze rozhodovat pouze podle toho, že povrch dostal méně slunce.</p>
<h3>6. Co lze z této zprávy skutečně vyčíst</h3>
<p>Vlastní kontrolní model pro referenční tropický profil při zvýšení CO₂ z 280 na 420 ppm vypočítal změnu krátkovlnného příkonu absorbovaného povrchem přibližně <strong>{num(r['surface'])} W/m²</strong>. Záporné znaménko znamená menší příkon. Jde o zjednodušený atmosférický sloupec s pevnou teplotou, bez oblaků a aerosolů, při zvolené geometrii osvětlení. <strong>Tato hodnota není globálním ročním odhadem ani výpočtem ochlazení mezní vrstvy v °C.</strong></p>
<p>K úplné teplotní odpovědi je nutné navíc vypočítat změnu tepelného vyzařování, vypařování, turbulentního přenosu, oblačnosti a proudění. Následující odborná část odděluje skutečně provedené čárové výpočty, kontrolu publikovaných čísel a části, které zůstaly nevyřešené.</p>
''')

add('rozsah','1. Výzkumná otázka a rozsah dokončené práce',f'''
<p>Zkoumáme řetězec <strong>vyšší CO₂ → změna SW absorpce podle výšky → změna příkonu povrchu → radiační a dynamická odezva</strong>. Znaménko jednotlivých článků tohoto řetězce ověřujeme odděleně. Podklady neumožňují považovat všechny jeho části za vyřešené jediným číslem.</p>
{table(['Část úkolu','Stav','Co je dodáno'],[
['Vlastní spektrální přenos','Proveden v omezeném modelu','CO₂ + H₂O, čárová absorpce, šest referenčních profilů, rozptyl a odrazy'],
['Hlavní koncentrace','Provedeno','278 → 417; 280 → 420; 420 → 560; 280 → 560; 280 → 1120 ppm'],
['Dlouhovlnná adaptace','Vlastním úplným modelem neprovedena','Aritmetická kontrola tabulky Shine; analytický test znaménka'],
['Klimatická odezva mezní vrstvy','Nezávisle nereprodukována','Vysvětlen mechanismus a chybějící bilanční členy'],
['Globální roční hodnota','Neurčena','Šest sloupců bez klimatologických vah ji nenahrazuje'],
['Audit článků','Částečný','Kontrola definic, aritmetiky, publikovaných experimentů a vybraných autorských dat']])}
{note('Toto je dokončený omezený numerický experiment a částečný metodický audit. Nelze jej označit za úplnou reprodukci SOCRATES, CESM2, RRTMG ani za konvergovaný referenční benchmark celé atmosféry.','Rozsah platnosti')}
''')

add('metody','2. Metody a vstupní data',f'''
<p>Nově napsaný a skutečně spuštěný model počítá absorpci jednotlivých spektrálních čar CO₂ a H₂O s Voigtovým profilem, teplotní závislostí intenzit, tlakovým a Dopplerovým rozšířením. Používá přirozené izotopové zastoupení již obsažené v intenzitách HITRAN; toto zastoupení se nenásobí podruhé. Zvlášť přidává vodní kontinuum MT_CKD 4.3.</p>
{table(['Vstup nebo volba','Použitá konfigurace'],[
['Spektrální čáry','Uložený živý export HITRANonline z 18. 11. 2026, CO₂ a H₂O, 0–26 000 cm⁻¹; přesná edice není certifikována jako zmrazené HITRAN2024'],
['Partiční funkce','HAPI 1.3.0.0, TIPS2025; skutečné knihovny a otisky vstupů jsou v balíčku'],
['Sluneční spektrum na TOA','TSIS-1 HSRS v2, 1 nm, a binned full-spectrum extension; nejde o spektrum po průchodu atmosférou'],
['Atmosféry','AFGL 1986: tropy, střední šířky léto/zima, subarktida léto/zima, US standard'],
['Spektrální oblast modelu','250–26 000 cm⁻¹, tedy přibližně 0,385–40 µm; krátkovlnná složka je určena slunečním původem'],
['Hlavní spektrální kroky','0,010 / 0,005 / 0,010 / 0,100 / 1,000 cm⁻¹ v pěti intervalech popsaných v kódu'],
['Čáry a křídla','Práh S₂₉₆ ≥ 10⁻²⁶ cm/molekulu; ořez ±25 cm⁻¹; H₂O podstavec ve 25 cm⁻¹'],
['Výška','0–80 km; 4 km do 60 km, pak 5 km; tropická modelová tropopauza 16 km'],
['Osvětlení','Zenitový úhel 60° po polovinu času: násobek 0,5 × cos 60° = 1/4 pro vstupní tok; sám o sobě nejde o globální klimatologii'],
['Rozptyl a povrch','Dvouproudová kvadratura s μ = 1/√3; izotropní aproximace Rayleighova rozptylu; Lambertův povrch, základní albedo 0,06']])}
<p><strong>Záměrná zjednodušení:</strong> chybí absorpce O₃, O₂, CH₄ a N₂O, směšování čar CO₂, sublorentzovská korekce křídel, CO₂ kontinuum a kolizní absorpce, aerosolové a oblačné optické vlastnosti, úplná dlouhovlnná odezva a dynamika. Tlaková šířka CO₂ zůstává předpočítána při 280 ppm. Při změně vlhkosti se škáluje optická tloušťka referenční H₂O, včetně kontinua, bez nového výpočtu samorozšíření a jeho nelinearity. Hydrostatický sloupec používá pevnou střední molární hmotnost vzduchu.</p>
<p>Čárový součet proto představuje vlastní <strong>omezený LBL výpočet</strong>; dvouproudový přenos a neúplná fyzika jej odlišují od validovaného LBLRTM/ARTS benchmarku. Jiné radiační modely nebyly v tomto prostředí sestaveny ani spuštěny; jejich nedostupnost nebyla prokázána a úplný modelový audit zůstává otevřený.</p>
<p class="source">Definice čar a jejich jednotek: <a href="https://www.hitran.org/docs/definitions-and-units/">HITRAN</a>. Sluneční vstup: <a href="https://lasp.colorado.edu/lisird/data/tsis1_hsrs/">LASP, TSIS-1 HSRS v2</a> a <a href="https://lasp.colorado.edu/lisird/data/tsis1_hsrs_fs/">full-spectrum extension</a>. Atmosféry: <a href="https://www.libradtran.org/doku.php?id=basic_usage">popis standardních AFGL profilů v libRadtran</a>; uložené tabulky a jejich původ jsou v datovém manifestu.</p>
''')

mainrows=[]
for label,key in [('Změna SW absorpce celé atmosféry','atmosphere'),('Změna SW absorpce povrchem','surface'),('Změna odraženého SW na horní hranici','reflected'),('Změna SW absorpce pod 16 km','troposphere'),('Změna SW absorpce v 16–80 km','above_tropopause_to80'),('Přímý SW tok na povrchu, změna','direct_surface'),('Difuzní SW tok na povrchu, změna','diffuse_surface'),('Změna přímé absorpce CO₂','co2_absorption'),('Změna přímé absorpce H₂O','water_absorption'),('Okamžitá změna čistého SW toku na horní hranici','toa')]:
    mainrows.append([label]+[num(row(c1=c).get(key,float('nan')),6 if key=='diffuse_surface' else 3,True) for c in [420,560,1120]])
for label in ['Změna LW do vesmíru po vlastní adaptaci','Změna LW dolů na tropopauze po vlastní adaptaci','Čistý SW vyvolaný účinek včetně LW adaptace','Úplná fyzikální nejistota']:
    mainrows.append([label]+['Neurčeno']*3)
add('vysledky','3. Vlastní numerické výsledky',f'''
<p>Všechny následující hodnoty patří <strong>tropickému referenčnímu sloupci</strong> ve výše popsané hlavní konfiguraci. Jednotkou je W/m². Změna vždy znamená konečný stav minus počáteční stav; teplota a ostatní referenční vlastnosti zůstávají pevné.</p>
{table(['Veličina, okamžitá změna','280 → 420 ppm','280 → 560 ppm','280 → 1120 ppm'],mainrows)}
<p>Pro 278 → 417 ppm vychází změna SW absorpce povrchu <strong>{num(row(c0=278,c1=417)['surface'])} W/m²</strong>; pro 420 → 560 ppm <strong>{num(row(c0=420,c1=560)['surface'])} W/m²</strong>. Koncentrace 420 ppm je zadaný scénář, nikoli tvrzení o aktuálním měřeném průměru v listopadu 2026.</p>
<p>Hlavní toky uvádíme na tři desetinná místa pro kontrolu bilance; malé difuzní změny na šest. Počet desetinných míst nevyjadřuje známou fyzikální přesnost. Přímý a difuzní tok jsou sestupné složky před povrchovým odrazem; změna absorbovaného příkonu povrchu se rovná jejich součtu násobenému 1 − α.</p>
{f6}
{note('Všechny buňky „Neurčeno“ označují skutečně neprovedený výpočet. Nejsou nahrazeny přepočtem z logaritmické parametrizace celkového působení CO₂ ani přenesením výsledku z jiného článku.','Chybějící výsledky jsou viditelné')}
''')

add('spektra','4. Spektrální výsledky a překryv s vodní párou',f'''
{f1}{f2}
<p>Přírůstek přímé absorpce CO₂ v hlavním experimentu je <strong>{num(r['co2_absorption'])} W/m²</strong>. Změna absorpce H₂O je současně <strong>{num(r['water_absorption'])} W/m²</strong>. Jejich součet je změna absorpce celé atmosféry <strong>{num(r['atmosphere'])} W/m²</strong>. Tento výpočet přímo dokládá, proč nelze zvýšenou absorpci samotným CO₂ vydávat za stejně velké zvýšení celkového atmosférického ohřevu.</p>
<p>Rozdělení podle plynu používá podíl jeho absorpční optické tloušťky na součtu CO₂ + H₂O v každé vrstvě a na každé spektrální buňce. Platí pro homogenní složení jednotlivé vrstvy. Rozptyl sám energii nepohlcuje.</p>
{f7}
<p>V suchém kontrolním sloupci se pokles povrchové absorpce mění na <strong>{num(row(kind='dry')['surface'])} W/m²</strong>; při 1,5násobku referenční optické tloušťky H₂O na <strong>{num(row(kind='wet')['surface'])} W/m²</strong>. Tyto stavy slouží k izolaci překryvu spekter. Nejsou předpovědí skutečné klimatické změny vlhkosti.</p>
''')

bands=[(.385,1.4),(1.4,1.8),(1.8,2.2),(2.2,3.2),(3.2,5.5),(5.5,40.)]
bandrows=[]
for a,b in bands:
    ss=[s for s in sp if a<=s['lambda_um']<b]
    bandrows.append([f'{num(a,3)}–{num(b,1)}',num(sum(s.get('delta_co2_absorption_Wm2',0) for s in ss),4,True),
                     num(sum(s['delta_atmosphere_Wm2'] for s in ss),4,True),num(sum(s['delta_surface_Wm2'] for s in ss),4,True)])
add('vyska','5. Výškové rozdělení a energetická bilance',f'''
{f3}{f4}
<p>V hlavním tropickém experimentu připadá na oblast pod 16 km změna absorpce <strong>{num(r['troposphere'])} W/m²</strong> a na oblast 16–80 km <strong>{num(r['above_tropopause_to80'])} W/m²</strong>. Jde o čistou změnu absorpce všech zahrnutých plynů; zahrnuje i změnu toho, v jaké vrstvě by byla energie pohlcena. Kladný či záporný přírůstek lokální absorpce nesmí být zaměněn s celkovým klimatickým teplotním trendem.</p>
<p><strong>Oblast 16–80 km zahrnuje kromě stratosféry také mezosféru.</strong> Na dostupných rozhraních modelu vychází pro 16–48 km {num(sum(p['delta_absorption'] for p in pp if p['z0']>=16 and p['z1']<=48))} W/m² a pro 48–80 km {num(sum(p['delta_absorption'] for p in pp if p['z0']>=48))} W/m². Tyto přesně vymezené intervaly nenahrazujeme označením „celá stratosféra“; její proměnlivou horní hranici model samostatně neurčuje.</p>
{eq('F<sub>net</sub>(z) = F↓(z) − F↑(z) &nbsp; [W/m²]; &nbsp; A<sub>vrstva</sub> = F<sub>net</sub>(horní hranice) − F<sub>net</sub>(dolní hranice).')}
{eq('ΔA<sub>TOA</sub> = ΔA<sub>povrch</sub> + ΔA<sub>atmosféra</sub>')}
{eq(num(r['toa'],6)+' = '+num(r['surface'],6)+' + '+num(r['atmosphere'],6)+' &nbsp; W/m²')}
<p>Horní hranice vlastního modelu je 80 km. Označení TOA se v jeho tabulkách používá jako zkratka pro tuto hranici, nikoli pro přesný výpočet celé atmosféry až do vesmíru. Při stejném vstupním slunečním toku je ΔA<sub>TOA</sub> = −ΔF↑<sub>SW,TOA</sub>. Atmosféra může při menším příkonu povrchu současně zvýšit součet energie pohlcené celou soustavou tím, že méně záření unikne po odrazu.</p>
{eq('Δ(dT/dt)<sub>SW</sub> = g · ΔA<sub>vrstva</sub> / (c<sub>p</sub> · Δp); &nbsp; pro K/den násobíme 86 400.')}
<p>Výpočet krátkovlnné absorpce do 80 km nezahrnuje řešení excitovaných hladin mimo lokální termodynamickou rovnováhu. Zvláště teplotní a dlouhovlnný výklad horních vrstev by vyžadoval kontrolu non-LTE fyziky. Z grafu rychlosti ohřevu proto neodvozujeme vývoj skutečné teploty v mezosféře.</p>
<h3>Integrály spektrálních příspěvků</h3>
{table(['Vlnová délka (µm)','Δ absorpce přímo CO₂','Δ absorpce celé atmosféry','Δ absorpce povrchu'],bandrows)}
<p class="small">Jednotky W/m²; integrace je provedena z uložených spektrálních buněk, hranice pásem jsou přiřazeny podle středu buňky. Tabulka obsahuje i slabý sluneční příspěvek na delších infračervených vlnách.</p>
''')

add('profily','6. Suché a vlhké profily, albedo a modelové srovnání',f'''
{f8}
<p>Šest profilů bylo skutečně vypočteno při shodné hrubší konfiguraci: osmikilometrové vrstvy do 60 km, spektrální kroky dvojnásobné proti hlavnímu běhu, práh intenzity 10⁻²⁵ a ořez křídel ±5 cm⁻¹. Tyto výsledky slouží k orientačnímu porovnání sloupců; jejich přesnost ani rozdělení kolem tropopauzy nelze převzít z jemnějšího tropického běhu. Modelová tropopauza je zde určena nejnižší teplotou do 25 km na dané řídké mřížce.</p>
{table(['Kontrolní tropický povrch','Albedo','Δ SW absorbované povrchem','Δ čisté SW na horní hranici'],[
['Tmavý povrch', '0,06',num(r['surface']),num(r['toa'])],
['Střední albedo','0,20',num(row(kind='land')['surface']),num(row(kind='land')['toa'])],
['Velmi světlý povrch','0,80',num(row(kind='snow')['surface']),num(row(kind='snow')['toa'])]])}
<p>Jednotky toků jsou W/m². Povrch s albedem 0,80 je záměrný citlivostní test s konstantním spektrálním albedem. Nenahrazuje skutečné spektrum sněhu. Mění se současně absorpce povrchu i energie opakovaně procházející atmosférou.</p>
<p><strong>Co zde není vypočteno:</strong> nízké a vysoké oblaky, aerosoly, reálné oceánské směrové odrazy, roční geografické váhy ani přímé srovnání SOCRATES/RRTMG/RRTMGP na stejných vstupech. Není poctivé vykreslit rozdíl našich čísel vůči publikovanému globálnímu výsledku jako „chybu jejich modelu“, protože vstupy a definice nejsou shodné.</p>
<p>Oficiální <a href="https://confluence.ecmwf.int/spaces/CKDMIP/pages/278535613/RTE-RRTMGP%2Bv1.5%2Bresults%2Bfull%2Band%2Breduced%2Bspectral%2Bresolution">benchmark RTE-RRTMGP v1.5</a> hodnotí novější krátkovlnné konfigurace příznivě; přesnost ale závisí na koncentraci a rozlišení. To podporuje potřebu kontrolovat konkrétní verzi a spektrální data, nikoli mechanicky přiřadit starou chybu všem novějším modelům.</p>
''')

add('adaptace','7. Následné vyzařování a význam pro mezní vrstvu',f'''
<p>Pro izolaci krátkovlnně vyvolané odezvy je správný diferenční operátor:</p>
{eq('Δ<sub>SW vyvolané</sub>X = [X(C₁, SW zapnuto) − X(C₀, SW zapnuto)] − [X(C₁, SW vypnuto) − X(C₀, SW vypnuto)].')}
<p>Všechny čtyři členy musí mít shodná ostatní pravidla experimentu. Povolit stratosférické teplotě změnu znamená jiný experiment než povolit i vodní páře, oblačnosti a proudění rychlé úpravy. Vlastní krátkovlnný běh má pevný atmosférický stav; tento úplný čtyřčlenný teplotní experiment neřeší.</p>
{f5}
<p>Náš přepočet tabulky Shine dává rozdíl SW toků mezi horní hranicí a tropopauzou 0,07 − (−0,12) = <strong>0,19 W/m²</strong>. Změny následného LW výdeje odvozené porovnáním s LW-only případem jsou <strong>0,12 W/m² vzhůru</strong> a <strong>0,07 W/m² dolů</strong>. Jejich součet uzavírá tuto stratosférickou bilanci. Jde o diferenční toky obou experimentů; ne o sledování osudu původních slunečních fotonů.</p>
<p>Při hypotetickém podílu f směrem vzhůru vychází na horní hranici ΔF = 0,07 − f × 0,19. Poměr z tabulky f = 0,12/0,19 = 0,632 vede k −0,05 W/m². Přibližně 63 % takto definovaného <em>dodatečného radiačního ochlazování stratosféry</em> připadá na horní hranici. Tento poměr není obecnou vlastností CO₂ a neurčuje podíl energie, která dosáhne zemského povrchu.</p>
{f9}
<h3>Proč z W/m² automaticky nevyjde ochlazení mezní vrstvy</h3>
{eq('C<sub>s</sub> · dT<sub>s</sub>/dt = SW<sub>net,s</sub> + LW↓<sub>s</sub> − LW↑<sub>s</sub> − H − LE − G<sub>půda/oceán</sub>.')}
<p>H je tok citelného tepla z povrchu do vzduchu, LE tok energie spojený s vypařováním a poslední člen odvod do půdy nebo oceánu. Teplotu mezní vrstvy navíc ovlivňují její vlastní radiační toky, směšování s vyšším vzduchem, advekce, vlhkost a proměnlivá hloubka. Menší SW<sub>net,s</sub> je ochlazující člen povrchové bilance; znaménko celkové odezvy vzduchu potřebuje vyhodnocení všech těchto procesů.</p>
<p>Pro představu o jednotkách: ideálně uzavřená, 1 km hluboká vrstva vzduchu s hustotou 1,2 kg/m³ a c<sub>p</sub> = 1004 J/(kg·K) by při čisté energetické ztrátě 1 W/m² měnila teplotu rychlostí asi <strong>−0,072 K za den</strong>. Je to vlastní výpočet tepelné kapacity, který předpokládá, že celá ztráta patří právě vzduchu. <strong>Není to odhad ochlazení způsobeného CO₂</strong>; vypočtenou ztrátu příkonu povrchu nelze do této krabičky bez dalších rovnic dosadit.</p>
''')

add('audit','8. Kritický audit publikací',f'''
<article class="audit"><h3>Shine, Byrom a Checa-Garcia (2022)</h3>
<p><strong>Tvrzení a metoda:</strong> tabulka 3 uvádí globální lednové toky pro 278 → 417 ppm. SOCRATES má 6 SW a 9 LW pásem, horizontální mřížku 5° × 5° a stratosférickou adaptaci při pevném dynamickém ohřevu. Celkové působení je 2,14 W/m², proti LW-only 2,19 W/m². <strong>Naše kontrola:</strong> rozdíl −0,05 W/m² a pokles o 2,283 % aritmeticky i bilančně souhlasí.</p>
<p><strong>Omezení:</strong> jde o leden; hodnoty nejsou tokem na povrchu. Jemnější nezávislá radiační reprodukce nebyla dokončena. <strong>Protiargument k silné kritice:</strong> odlišná znaménka okamžitého SW toku nahoře a na tropopauze bilanci neporušují. <strong>Verdikt:</strong> vnitřní aritmetika potvrzena; absolutní velikost −0,05 W/m² nezávisle neověřena.</p>
<p class="source"><a href="https://rmets.onlinelibrary.wiley.com/doi/10.1002/asl.1116">Původní článek, tabulka 3</a>.</p></article>
<article class="audit"><h3>Allen et al. (2024)</h3>
<p><strong>Tvrzení a metoda:</strong> CESM2/CAM6 s RRTMG odděluje účinky dvojím rozdílem. Pro 2×CO₂SW je ERF −0,03 ± 0,15 W/m², pro 4×CO₂SW −0,35 ± 0,15 W/m²; teplotní odezva 4×CO₂SW je −0,38 ± 0,12 K. Uvedené intervaly jsou 90%. Spřažený oceánský experiment byl kvůli slabému signálu proveden jen pro 4×CO₂; simulace běžela 90 let a vyhodnocuje posledních 40.</p>
<p><strong>Kontrola a nejistoty:</strong> jde o klimatickou odezvu včetně atmosférických úprav, nikoli o přímý spektroskopický pokles teploty. Statistický rozbor vyžaduje roční řady, jejich autokorelaci a kovariance čtyř porovnávaných běhů. <strong>Verdikt:</strong> význam a čísla ověřeny v textu; klimatický výpočet nereprodukován. <strong>Protiargument:</strong> samotná modelová závislost výsledek nevyvrací; omezuje zobecnění.</p>
<p class="source"><a href="https://acp.copernicus.org/articles/24/11207/2024/">Původní článek, oddíly 2 a 3.3</a>.</p></article>
<article class="audit"><h3>Hogan a Matricardi (2020): CKDMIP</h3>
<p><strong>Tvrzení a podmínky:</strong> podhodnocení 25–45 % se týká okamžitého krátkovlnného radiačního působení RRTMG v testech CO₂ a CH₄, scénáře 5–14, proti line-by-line referenci. Referencí je současný stav, ostatní plyny jsou pevné; hodnotí se TOA i povrch, soubor 50 profilů a pět slunečních úhlů. Rozsah CO₂ zahrnuje až 8násobek předindustriální hodnoty. Odezva rychlosti ohřevu může být přitom zachycena poměrně dobře.</p>
<p><strong>Naše posouzení:</strong> text nedává obecnou procentní opravu každé čáry ani teplotní odezvy. Neurčuje jediné vadné pásmo CO₂; zmiňuje prostor pro zlepšení slabé absorpce. <strong>Verdikt:</strong> omezení původního RRTMG doloženo; přesný nový benchmark zde neproveden. <strong>Protiargument:</strong> dobrý profil ohřevu nevylučuje chybu malého rozdílu hraničních toků.</p>
<p class="source"><a href="https://gmd.copernicus.org/articles/13/6501/2020/">Původní článek, tabulka 2 a obrázek 8</a>.</p></article>
<article class="audit"><h3>Cohen, Pincus a Polvani (2026)</h3>
<p>Práce vysvětluje stratosférické ochlazování a jeho vliv na působení CO₂. Pro naši otázku je nutné odlišit zjednodušenou teorii od numerických běhů. <strong>Vlastní kontrola autorských dat:</strong> ve třech uložených adaptovaných stavech 280, 560 a 1120 ppm není SW ohřev totožný. Maximální rozdíl proti 280 ppm je <strong>{num(cohen['560']['sw_htngrt'])}</strong> a <strong>{num(cohen['1120']['sw_htngrt'])} K/den</strong>. Maximální rozdíl sestupného SW toku je {num(cohen['560']['sw_flxd'])} a {num(cohen['1120']['sw_flxd'])} W/m².</p>
<p>Tyto rozdíly zahrnují změny atmosférických stavů, nejsou izolovaným okamžitým účinkem CO₂ a neprokazují chybu teorie. <strong>Verdikt:</strong> doslovně konstantní SW ohřev nelze připsat všem zveřejněným výstupům. Oprávněnost jeho aproximace v konkrétním analytickém odvození bez úplné reprodukce nezávisle nerozhodujeme.</p>
<p class="source"><a href="https://www.nature.com/articles/s41561-026-01965-8">Článek</a> a <a href="https://doi.org/10.5281/zenodo.16929030">autorský datový archiv</a>; kontrolní skript a přesné otisky tří netCDF souborů jsou přiloženy.</p></article>
<article class="audit"><h3>Starší a další nezávislé podklady</h3>
<p><a href="https://doi.org/10.1029/98GL01908">Myhre et al. (1998)</a> je výchozí práce. Její krátkovlnné číselné údaje zde nebyly nezávisle rekonstruovány z primárních běhů; zůstává bibliografickým zdrojem.</p>
<p><a href="https://agupubs.onlinelibrary.wiley.com/doi/10.1002/2016GL071930">Etminan et al. (2016)</a> zahrnuje krátkovlnné pásy do radiačních výpočtů a u CO₂ popisuje příspěvek působící proti LW-only účinku přibližně o 5 %. Rozdíl proti 2,3 % v jiném experimentu sám o sobě není chybou. Je nutné sjednotit koncentrace, referenční stav, spektra, tropopauzu a adaptaci. Vlastní nový výpočet jejich procenta není součástí této zprávy.</p>
<p><a href="https://acp.copernicus.org/articles/25/11689/2025/">Studie o krátkovlnném vodním kontinuu (2025)</a> porovnává několik parametrizací kontinua. Je relevantní jako upozornění na citlivost překryvu absorpce, nikoli jako přímé měření krátkovlnného účinku CO₂ na mezní vrstvu.</p>
</article>
''')

add('nejistoty','9. Numerická kontrola, nejistoty a vlastní kritika',f'''
{f10}
{table(['Jednofaktorová změna nastavení','Změna výsledku SW povrchu (W/m²)'],[[k,num(v,6,True)] for k,v in sens])}
<p>Citlivosti nelze sčítat v kvadratuře jako nezávislé náhodné chyby. Poloviční spektrální krok je dílčí kontrola konvergence, nikoli důkaz úplné konvergence všech výškových ohřevů. Neproběhla dostatečná zjemňovací řada vertikálních vrstev ani práh intenzity směřující k nule. Interval fyzikální nejistoty tedy není určen.</p>
{table(['Zdroj nejistoty','Co bylo ověřeno','Co zůstává otevřené'],[
['Numerická Voigtova funkce','Kontrola proti scipy.special.wofz; maximální relativní odchylka přibližně 6,9 × 10⁻⁵ v testované sadě','Nepokrývá nejistotu skutečných spektroskopických parametrů'],
['Rozlišení a slabé čáry','Dílčí citlivosti uložené v grafu','Plně konvergované spektrum všech profilů'],
['Křídla a kontinua','Ořez 10 a 25 cm⁻¹; H₂O podstavec 25 cm⁻¹','Validace CO₂ line mixing, sublorentzovských křídel, CIA a nejistot MT_CKD'],
['Rozptyl','Analytické nulové a konzervativní limity dvouproudového řešiče','Srovnání proti víceproudovému řešení a skutečné Rayleighově fázové funkci'],
['Atmosférický stav','Šest referenčních profilů','Klimatologické váhy, proměnlivost a další plyny'],
['Následné odezvy','Aritmetika publikované stratosférické bilance','Vlastní LW jádro, teplotní adaptace, oblaky a dynamika mezní vrstvy']])}
<p><strong>Kontroly skutečně spuštěné na řešiči:</strong> nulová absorpce s konzervativním rozptylem, čistá Beerova–Lambertova absorpce, povrchové pohlcení (1 − α), kladná absorpce při pevném složení, součet spektrálních a vrstevních toků a shoda změny TOA s opačnou změnou odrazu. Samotné teleskopické uzavření vrstvené bilance není nezávislou validací vstupní fyziky.</p>
<p><strong>Potenciální statistický problém k ověření v úplném auditu Allen:</strong> interval pro rozdíl průměrů vyžaduje směrodatnou chybu, nikoli pouze směrodatnou odchylku. Pro dva nezávislé běhy platí přibližně SE = s<sub>p</sub>√(1/n₁ + 1/n₂); pro dvojí rozdíl jsou potřebné i případné kovariance a efektivní délky korelovaných řad. Z formulace metody v článku bez jeho ročních dat nelze rozhodnout, zda jde pouze o zkratku zápisu, nebo o problém realizace. Chybu výsledných intervalů zde netvrdíme.</p>
''')

add('zavery','10. Odpovědi na výzkumné otázky a priority',f'''
{table(['Otázka','Závěr v rozsahu tohoto auditu'],[
['A. O kolik se sníží SW příkon povrchu při 280 → 420 ppm?',f'Vlastní omezený tropický sloupec: {num(r["surface"])} W/m². Globální roční hodnotu tato zpráva neurčuje.'],
['B. Kolik připadá na troposféru a stratosféru?',f'V tomto sloupci {num(r["troposphere"])} W/m² pod 16 km a {num(r["above_tropopause_to80"])} W/m² v 16–80 km; horní oblast zahrnuje i mezosféru. Čistě stratosférický a globální podíl nejsou samostatně určeny.'],
['C. Jak se změní vyzařování do vesmíru po adaptaci?','Vlastním modelem neurčeno. Z tabulky Shine vychází SW vyvolaný přírůstek LW výdeje 0,12 W/m², pro jejich konkrétní experiment.'],
['D. Jaký je čistý SW vyvolaný radiační příspěvek CO₂?','Aritmetika Shine: −0,05 W/m² pro 278 → 417 ppm. Nejde o výsledek našeho úplného radiačního modelu ani o ztrátu příkonu samotného povrchu.'],
['E. Jaká je nejistota?','Numerické citlivosti jsou vyčísleny. Celkový fyzikální interval a nejistota globální hodnoty nejsou stanoveny.'],
['F. Jsou publikace správné?','Shine: souhlasí aritmetika. Allen: ověřen obsah experimentů, bez reprodukce klimatu. CKDMIP: doložen konkrétní benchmark, bez nové reprodukce. Cohen: zkontrolována vybraná autorská data. Žádný z těchto kroků není úplným potvrzením nebo vyvrácením všech výsledků.'],
['G. Lze účinek zanedbat?','V přesné kvantitativní bilanci je nutné jej explicitně zahrnout. Z dokončených výpočtů však nelze určit jeho univerzální význam pro teplotu mezní vrstvy ani tvrdit čistý ochlazující účinek celkového růstu CO₂.']])}
<h3>Co by odstranilo největší otevřené otázky</h3>
<p>První prioritou je víceplynový, víceproudový, spektrálně konvergovaný výpočet na shodných sloupcích s validovaným LBLRTM nebo ARTS. Následuje dlouhovlnná radiační matice pro stratosférickou adaptaci a úplný čtyřčlenný experiment se zapnutou a vypnutou SW absorpcí. Teprve klimatologicky vážené sloupce a experiment s pevnými povrchovými teplotami mohou oddělit globální okamžité působení od rychlých úprav; spřažená simulace potom určí teplotní odezvu mezní vrstvy.</p>
<p><strong>Fyzikálně doložený význam mechanismu:</strong> dodatečná absorpce slunečního záření CO₂ může zmenšovat ohřev povrchu. <strong>Vlastní čárový experiment tento dílčí pokles zachytil.</strong> Číselná odpověď, o kolik tento mechanismus ochladí skutečnou přízemní mezní vrstvu v globálním průměru, zůstává otevřená.</p>
''')

add('reprodukce','Reprodukovatelnost, data a zdroje',f'''
<p>Balíček obsahuje zdrojový kód, původní čárové vstupy, sluneční data, šest AFGL profilů, tři kontrolované autorské netCDF soubory, JSON a CSV výsledky, deset grafů SVG, záznam verzí a SHA-256 manifest. Grafy i výklad jsou vložené do HTML, takže čtení zprávy nevyžaduje internet.</p>
<div class="downloads"><a href="co2_audit.zip">Stáhnout celý reprodukční balíček ZIP</a><a href="co2_audit/results/fluxes.csv">Tabulka toků CSV</a><a href="co2_audit/results/height_profiles.csv">Výškové profily CSV</a><a href="co2_audit/README.md">Technická dokumentace</a></div>
<p>Pro opakování použijte Python 3.9 nebo kompatibilní prostředí s přesnými verzemi v <code>requirements.txt</code>. Hlavní běh: <code>python model.py --profile tropical --factor 5 --cutoff 1e-26 --wing 25 --dz 4</code>. Kontroly: <code>python verify.py</code>; audit publikovaných čísel: <code>python audit.py</code>; autorská data 2026: <code>python check_cohen.py</code>. Úplný seznam spuštěných nastavení je v <code>experiments.json</code>.</p>
<p class="small">Zpracováno 19. listopadu 2026. Vlastní numerické výsledky představují výpočet za popsaných předpokladů, nikoli přímé měření. Převzaté hodnoty jsou vždy pojmenovány u konkrétní publikace. Součástí balíčku je i původní zadání se soupisem požadavků.</p>
''')

css='''
:root{--ink:#213947;--muted:#5c707c;--line:#dce5e8;--teal:#087f83;--paper:#fff;--bg:#f2f5f4}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:28px}body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.75 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}a{color:#076977;text-underline-offset:3px}a:hover{color:#06434b}header{background:#123946;color:#fff;padding:48px max(30px,calc((100vw - 1280px)/2));border-bottom:6px solid #44b6ac}.eyebrow{letter-spacing:.13em;font-size:12px;font-weight:750;text-transform:uppercase;color:#a9dfd9}h1{font-size:clamp(29px,3.5vw,48px);line-height:1.17;max-width:1050px;letter-spacing:-.025em;margin:16px 0}header p{max-width:900px;color:#dbe9ed;font-size:18px}.meta{font-size:13px;color:#b7d4d8}.layout{max-width:1380px;margin:auto;display:grid;grid-template-columns:230px minmax(0,1fr);gap:35px;padding:35px 30px 80px}nav{position:sticky;top:25px;align-self:start;font-size:13px;line-height:1.5}nav b{display:block;letter-spacing:.08em;font-size:11px;text-transform:uppercase;color:var(--muted);margin-bottom:12px}nav a{display:block;color:var(--muted);text-decoration:none;padding:7px 0;border-bottom:1px solid var(--line)}main{min-width:0}section{background:var(--paper);padding:36px 40px;margin-bottom:24px;border:1px solid var(--line);border-radius:8px;box-shadow:0 3px 14px #193f4910}h2{font-size:26px;line-height:1.3;letter-spacing:-.015em;margin:0 0 22px}h3{font-size:20px;line-height:1.4;margin-top:31px;margin-bottom:10px}p{margin:0 0 18px}.lead{font-size:20px;line-height:1.7}.steps{display:grid;grid-template-columns:repeat(3,1fr);gap:15px;margin:28px 0 36px}.steps>div{border:1px solid #bcdedb;background:#f1faf8;padding:21px;border-radius:8px}.steps b{display:inline-grid;place-items:center;width:31px;height:31px;background:var(--teal);color:white;border-radius:50%;font-size:16px}.steps h3{font-size:17px;margin-top:15px}.steps p{font-size:15px;line-height:1.55;margin-bottom:0}.note{border-left:4px solid var(--teal);background:#edf7f5;padding:18px 22px;margin:25px 0}.note p{margin:6px 0 0}.note strong{font-size:15px}.equation{font-family:Georgia,"Times New Roman",serif;font-size:18px;padding:19px 22px;background:#f3f6f8;border:1px solid var(--line);border-radius:6px;margin:21px 0;overflow-wrap:anywhere}.table-scroll{max-width:100%;overflow-x:auto;margin:22px 0}table{border-collapse:collapse;width:100%;font-size:14px;line-height:1.6}th{background:#eaf1f2;color:#244854;text-align:left;font-weight:750}th,td{border-bottom:1px solid var(--line);padding:13px 14px;vertical-align:top}td:first-child{font-weight:600}tr:nth-child(even) td{background:#f8faf9}figure{margin:27px 0 32px;border:1px solid var(--line);border-radius:6px;background:white;padding:12px 15px 16px}figure svg{width:100%;height:auto;display:block}figcaption{font-size:13px;line-height:1.6;color:var(--muted);padding:9px 8px 0}.source,.small{font-size:13px;color:var(--muted)}.audit{padding-bottom:15px;border-bottom:1px solid var(--line)}.audit:last-child{border:0}.downloads{display:flex;flex-wrap:wrap;gap:10px;margin:22px 0}.downloads a{background:#e7f2f0;border:1px solid #bfdbd6;border-radius:5px;padding:9px 13px;font-size:13px;text-decoration:none;font-weight:650}code{font-size:.82em;background:#eef2f4;border-radius:4px;padding:2px 5px;overflow-wrap:anywhere}button{border:1px solid #a3c7ce;border-radius:5px;padding:8px 13px;background:transparent;color:#e1f3f1;cursor:pointer}footer{max-width:1100px;margin:0 auto 50px;padding:0 30px;font-size:13px;color:var(--muted)}
@media(max-width:1000px){.layout{grid-template-columns:1fr;padding:22px 20px}nav{position:static;display:flex;flex-wrap:wrap;gap:5px 15px}nav b{width:100%;margin:0}nav a{max-width:46%;padding:4px 0}section{padding:28px}.steps{gap:10px}.steps>div{padding:16px}}
@media(max-width:600px){body{font-size:16px;line-height:1.7}header{padding:30px 22px}header p{font-size:16px}.layout{padding:16px 10px}.steps{grid-template-columns:1fr}.steps>div{display:block;padding:16px 18px}.steps h3{display:inline;font-size:17px;margin-left:9px}.steps p{margin-top:10px}.lead{font-size:18px}section{padding:24px 19px;border-radius:5px}h2{font-size:23px}h3{font-size:19px}nav{padding:0 10px 10px}nav a{max-width:100%;font-size:12px}table{font-size:12px;min-width:510px}th,td{padding:10px 11px}figure{padding:4px;margin-left:-9px;margin-right:-9px}.equation{font-size:16px;padding:13px}.downloads a{width:100%}}
@media print{html{scroll-behavior:auto}body{background:white;font-size:10pt;line-height:1.55}header{background:white!important;color:#173d49;padding:0 0 20px;border-bottom:2px solid #087f83}header p,.meta,.eyebrow{color:#345a66}h1{font-size:28pt}.layout{display:block;padding:20px 0}nav,button,.downloads{display:none}section{box-shadow:none;border:0;padding:10px 0;margin-bottom:20px}h2,h3{break-after:avoid}figure,.steps,.note{break-inside:avoid}table{font-size:8pt}.table-scroll{overflow:visible}a{color:#1d5365}footer{padding:0}@page{size:A4;margin:18mm}}
'''
toclinks=''.join(f'<a href="#{i}">{html.escape(t)}</a>' for i,t in toc)
css+='''
.toc-mobile{display:none}
@media(max-width:1000px){.toc-desktop{display:none}.toc-mobile{display:block;background:white;border:1px solid var(--line);border-radius:6px;padding:13px 18px;font-size:14px}.toc-mobile summary{cursor:pointer;font-weight:700;color:var(--teal)}.toc-mobile a{display:block;padding:6px 0;border-top:1px solid var(--line);margin-top:6px;text-decoration:none}}
@media print{.toc-mobile{display:none}}
'''
nav='<nav class="toc-desktop" aria-label="Obsah zprávy"><b>Obsah</b>'+toclinks+'</nav><details class="toc-mobile"><summary>Rozbalit obsah zprávy</summary>'+toclinks+'</details>'
doc='''<!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="description" content="Srozumitelný výklad krátkovlnné absorpce CO₂, vlastních omezených čárových výpočtů a jejich významu pro povrch a mezní vrstvu."><title>CO₂: menší sluneční ohřev povrchu a přízemní mezní vrstva</title><style>'''+css+'''</style></head><body><header><div class="eyebrow">Fyzikální rozbor • vlastní numerický experiment • částečný audit</div><h1>Jak může CO₂ omezovat sluneční ohřev povrchu a přízemního vzduchu</h1><p>Méně probíraná absorpční pásma CO₂, přerozdělení sluneční energie v atmosféře a jejich možný ochlazující příspěvek k přízemní mezní vrstvě.</p><div class="meta">19. listopadu 2026 &nbsp;·&nbsp; Úvod pro laika, dále metody, výpočty a zdroje &nbsp; <button type="button" onclick="window.print()">Tisk / uložit PDF</button></div></header><div class="layout">'''+nav+'<main>'+''.join(sections)+'''</main></div><footer>Znaménka toků: čistý směr dolů je kladný. Vlastní modelové výsledky, převzaté výsledky a nevyřešené otázky jsou ve zprávě odlišeny. HTML je samostatně čitelné bez připojení k internetu.</footer></body></html>'''
(ROOT.parent/'co2_kratkovlnna_absorpce.html').write_text(doc)
(ROOT/'index.html').write_text(doc.replace('href="co2_audit.zip"','href="../co2_audit.zip"').replace('href="co2_audit/','href="'))

# Machine-readable exports from every completed run.
datasets=[]
for p in sorted(RES.glob('*_f*.json')):
    d=json.loads(p.read_text());datasets.append((p.stem,d))
for target,key in [('fluxes.csv','rows'),('height_profiles.csv','profiles'),('spectra.csv','spectra')]:
    rr=[dict(experiment=tag,**v) for tag,d in datasets for v in d[key]]
    fields=list(dict.fromkeys(k for v in rr for k in v))
    with (RES/target).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rr)
(ROOT/'experiments.json').write_text(json.dumps([dict(id=t,**d['config']) for t,d in datasets],indent=2))
print('Built',ROOT.parent/'co2_kratkovlnna_absorpce.html','sections',len(sections),'figures',10)
